<?=link_tag('assets/table/table/images/icons/favicon.ico');?>
<?=link_tag('assets/table/table/fonts/font-awesome-4.7.0/css/font-awesome.min.css');?>
<?=link_tag('assets/table/table/vendor/animate/animate.css');?>
<?=link_tag('assets/table/table/vendor/select2/select2.min.css');?>
<?=link_tag('assets/table/table/vendor/perfect-scrollbar/perfect-scrollbar.css');?>
<?=link_tag('assets/table/table/css/util.css');?>
<?=link_tag('assets/table/table/css/main.css');?>

<style>
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu .dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -1px;
    }
</style>