<?php include dirname(__DIR__).'/temp_home.php'; ?>

<?php include ('general_exam_form.php');?>
</div>
</div>
<?php include dirname(__DIR__).'/js_sources.php'; ?>
</body>
</html>