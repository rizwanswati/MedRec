<?php include dirname(__DIR__).'/lab_home_temp.php'; ?>

<?php include ('chemical_examination_form.php');?>
</div>
</div>
<?php include dirname(__DIR__).'/js_sources.php'; ?>
</body>
</html