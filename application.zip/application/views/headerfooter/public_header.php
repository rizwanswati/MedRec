
<script
    src="https://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>


<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>

<!--===============================================================================================-->
<script src="<?=base_url('assets/Login_v1/Login_v1/vendor/jquery/jquery-3.2.1.min.js');?>"></script>
<!--===============================================================================================-->
<script src="<?=base_url('assets/Login_v1/Login_v1/vendor/bootstrap/js/popper.js');?>"></script>
<script src="<?=base_url('assets/Login_v1/Login_v1/vendor/bootstrap/js/bootstrap.min.js');?>"></script>
<!--===============================================================================================-->
<script src="<?=base_url('assets/Login_v1/Login_v1/vendor/select2/select2.min.js');?>"></script>
<!--===============================================================================================-->
<script src="<?=base_url('assets/Login_v1/Login_v1/vendor/tilt/tilt.jquery.min.js');?>"></script>
<script >
    $('.js-tilt').tilt({
        scale: 1.1
    })
</script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v1/Login_v1/js/main.js');?>"></script>


</body>
</html>
