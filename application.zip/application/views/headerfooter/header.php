<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Abbottabad Diabetes & Foot Care Center</title>
    <?=link_tag('assets/css/bootstrap.min.css')?>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?=base_url('assets/Login_v1/Login_v1/images/icons/favicon.ico');?>"/>

    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/vendor/bootstrap/css/bootstrap.min.css');?>
    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/fonts/font-awesome-4.7.0/css/font-awesome.min.css');?> 
    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/vendor/animate/animate.css');?>
    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/vendor/css-hamburgers/hamburgers.min.css');?>
    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/vendor/select2/select2.min.css');?>
    <!--===============================================================================================-->
<!--    <link rel="stylesheet" type="text/css" href="css/util.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/css/util.css');?>
<!--    <link rel="stylesheet" type="text/css" href="css/main.css">-->
    <?=link_tag('assets/Login_v1/Login_v1/css/main.css');?>
    <!--===============================================================================================-->

</head>
<body>


<!--======================================================================================================-->





