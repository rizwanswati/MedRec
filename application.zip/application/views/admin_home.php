<!DOCTYPE html>
<html>
<head>
    
    <?php include ('header_links.php'); ?>
    <?php include ('tableheaders_links.php'); ?>
    
</head>
<body>
<?php include('side_nav.php');?>
<?php include ('dashboard.php');?>
</div>
</div>



<?php include ('js_sources.php'); ?>
</body>
</html>


