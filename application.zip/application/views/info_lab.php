<!DOCTYPE html>
<html>
<head>

    <?php include ('header_links.php'); ?>
    <?php include ('tableheaders_links.php'); ?>

</head>
<body>
<?php include('lab_side_nav_temp.php');?>
<!--next form will load same admin_home.php but with different info form-->
