<!DOCTYPE html>
<html>
<head>

    <?php include ('header_links.php'); ?>
    <?php include ('tableheaders_links.php'); ?>

</head>
<body>
<?php include('side_nav_lab.php');?>
<?php include ('lab/chemexam.php');?>

</div>
</div>
<?php include ('js_sources.php'); ?>
</body>
</html>