<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: rizwanullah
 * Date: 12/22/2018
 * Time: 5:16 PM
 */
class Adminmodel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
}
